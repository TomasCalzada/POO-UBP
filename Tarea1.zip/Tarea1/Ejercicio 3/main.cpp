#include <iostream>
#include <QString>
#include <QDebug>


namespace oct {
    QString getVersion() {
        return ("v0.0.1 - 20240318");
    }
}

int main() {
    QString version = oct::getVersion();
    qDebug() << version;
    return 0;
}
