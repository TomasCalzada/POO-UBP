#include "login.h"
#include "mapa.h"
#include<QPainter>

Login::Login()
{
    lUsuario = new QLabel("Usuario");
    lClave = new QLabel ("Clave");
    leUsuario = new QLineEdit;
    leClave = new QLineEdit();
    pbEntrar = new QPushButton("Entrar");
    layout = new QGridLayout;
    mapa = new Mapa;



    layout -> addWidget (lUsuario, 0, 0, 1, 1);
    layout -> addWidget (lClave, 1, 0, 1, 1);
    layout -> addWidget (leUsuario, 0, 1, 1, 2);
    layout -> addWidget (leClave, 1, 1, 1, 2);
    layout -> addWidget (pbEntrar, 2, 1, 1, 1);

    this -> setLayout (layout);

    connect(pbEntrar, SIGNAL(pressed()), this, SLOT (slot_validarUsuario()));
}

void Login::slot_validarUsuario() {
    if (leUsuario -> text() == "admin" && leClave -> text() == "1234"){
        mapa->show();
        this->close();
    }
    else {
        leClave->clear();
    }
}



