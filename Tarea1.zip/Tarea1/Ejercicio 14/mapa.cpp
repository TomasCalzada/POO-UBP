#include "mapa.h"
#include<QPainter>

    void Mapa::paintEvent (QPaintEvent *) {
        QPainter painter(this);

        painter.drawLine (0, 0, this->width(), this->height());
        QImage im("C:/Users/tomas/OneDrive/Documents/Facultad/SEMESTRE/5POO/images.jpg");
        painter.drawImage(0, 0, im);
    };
